# PM Agent Starter Kit

Thanks for joining the list. These three skills are the agent side of how I run projects with AI. Instead of checking something you paste in, they read your connected tools on a schedule and keep you ahead of the project.

By Justin Scoville, PMP, PgMP. Published by Ondatrace (https://ondatrace.com). Free under the MIT License.

## What's inside

| Skill | What it does | Runs |
| --- | --- | --- |
| Build the Project Memory | One short, sourced file with a project's people, decisions, dates, promises and open questions, so every new chat starts from the same context. Keeps a history of what changed. | Weekly refresh |
| Track My Promises | Finds what you said you'd do and what others said they'd do for you, across email, chat and transcripts. Flags what is overdue and drafts friendly nudges. | Workday mornings |
| Sweep the Week | Compares this week against the project memory and reports only what moved, what contradicts something said earlier, and what was expected but didn't happen. | Friday afternoon |

## Install

**Claude (claude.ai, desktop or mobile):** Upload each of the three .zip files in this folder under Settings > Capabilities > Skills. Then connect the tools you want them to read (email, chat, calendar, Jira and so on). Help: https://support.claude.com/en/articles/12512180-use-skills-in-claude

**Claude Code:** Copy the folders in `source/` into your skills directory.

**ChatGPT, Gemini, Copilot or another assistant:** Open a skill's `SKILL.md` in `source/`, copy the text and paste it into a chat, or save it as reusable instructions. Scheduling and connected tools depend on what your assistant supports. Pasted excerpts always work.

## Start here

1. Pick one real project and say: "Build the project memory for <project>." Approve the sources it reads and correct anything it gets wrong. The other two build on this file.
2. Say: "Track my promises for the last two weeks."
3. Say: "Sweep the week for <project>." After the first run, let it schedule itself for Friday afternoons.

## What these will and won't do

- They read only the sources you approve, and cite a source and date for every claim.
- They never fill in an owner or a date nobody gave, and they show both sides when sources disagree.
- They draft messages but never send anything without your approval, including on a schedule.
- They keep personal, HR and health details out of the memory file.

## More

- 25 free PMO skills: https://github.com/jsconu/pmo-skills
- Got this from a colleague? Join the list: https://ondatrace.kit.com/pmo-skills
- Hit a case these get wrong? Email ondatrace@ondatrace.com. I read everything.
