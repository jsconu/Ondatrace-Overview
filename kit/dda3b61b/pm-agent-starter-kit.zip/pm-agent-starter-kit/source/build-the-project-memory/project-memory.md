# <Project name>: project memory

**Also called:** <other names people use>
**Last refreshed:** <date> · **Sources read:** <email, chat, Jira, transcripts, files>
**Read this first.** Every line cites its source. Blanks mean no source said it.

## Purpose and scope
- <what the project delivers and why, in one or two lines> (<source, date>)
- Out of scope: <items explicitly excluded> (<source, date>)

## People
| Name | Role on this project | Decides on | Source |
| --- | --- | --- | --- |
| <name> | Sponsor | <budget, scope, go-live> | <source, date> |
| <name> | <role> | <or "Not stated"> | <source, date> |

## Decisions
| Date | Decision | Decided by | Status | Source |
| --- | --- | --- | --- | --- |
| <date> | <decision in plain words> | <name> | Decided / Conditional on <x> / Proposed | <source> |

## Key dates
| Milestone | Date | Type | Source |
| --- | --- | --- | --- |
| <milestone> | <date> | Committed / Forecast / Target | <source, date> |

## Commitments between people
- <who> owes <whom> <what> by <date or "No date given"> (<source, date>)

## Constraints and dependencies
- <constraint or dependency, and who it affects> (<source, date>)

## Open questions
- <question, or two sources that disagree, quoted side by side> (<sources>)

## Changed
- <date>: <what changed, old → new> (<source of the change>)
